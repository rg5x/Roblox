-- make your own teleporter game for detections !!!

-- https://www.roblox.com/games/15361767679/Baseplate-lol